from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///C:\\Users\\13729\\PycharmProjects\\webbook\\test.db'
app.config['SECRET_KEY'] = '123456'
db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

# 图书模型
class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)

    def __repr__(self):
        return '<Book %r>' % self.name

# 用户模型
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15), unique=True)
    password = db.Column(db.String(80))

# 加载用户
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# 创建数据库表
with app.app_context():
    db.create_all()

# 处理登录
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False

        user = User.query.filter_by(username=username).first()

        if not user or not check_password_hash(user.password, password):
            return redirect(url_for('login'))

        login_user(user, remember=False)
        return redirect(url_for('index'))

    return render_template('login.html')

# 处理注册
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User(username=username, password=generate_password_hash(password, method='sha256'))

        db.session.add(user)
        db.session.commit()

        return redirect(url_for('login'))

    return render_template('signup.html')

# 处理登出
@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# 定义一些路由来处理用户的请求
@app.route('/')
@login_required
def index():
    books = Book.query.all()
    return render_template('index.html', books=books)

# 定义一个路由来添加新的图书
@app.route('/add', methods=['POST'])
@login_required
def add():
    name = request.form.get('name')
    book = Book(name=name)
    db.session.add(book)
    db.session.commit()
    return redirect(url_for('index'))

# 定义一个路由来删除图书
@app.route('/delete', methods=['POST'])
@login_required
def delete():
    id = request.form.get('id')
    book = Book.query.get(id)
    db.session.delete(book)
    db.session.commit()
    return redirect(url_for('index'))

# 定义一个路由来修改图书名
@app.route('/update', methods=['POST'])
@login_required
def update():
    id = request.form.get('id')
    new_name = request.form.get('new_name')
    book = Book.query.get(id)
    book.name = new_name
    db.session.commit()
    return redirect(url_for('index'))

# 定义一个路由来查询图书
@app.route('/search', methods=['POST'])
@login_required
def search():
    name = request.form.get('name')
    books = Book.query.filter(Book.name.contains(name)).all()
    return render_template('index.html', books=books)

if __name__ == '__main__':
    app.run(debug=True)
